package com.example.lindalabancz.jazzy;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

public class MusicScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_screen);

        ImageButton showInfo = (ImageButton) findViewById(R.id.infomusic);
        ImageButton showSettings = (ImageButton) findViewById(R.id.settingsmusic);

        showInfo.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                Intent showInfoIntent = new Intent(MusicScreen.this, MusicScreenInfo.class);
                startActivity(showInfoIntent);
            }
        });



        showSettings.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                Intent showSettingsIntent = new Intent(MusicScreen.this, MusicScreenSettings.class);
                startActivity(showSettingsIntent);
            }
        });
    }
}
