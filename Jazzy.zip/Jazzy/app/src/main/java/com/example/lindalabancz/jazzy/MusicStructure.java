package com.example.lindalabancz.jazzy;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class MusicStructure extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_structure);

        ImageButton playButton = (ImageButton) findViewById(R.id.playwhite);
        ImageButton albumButton01 = (ImageButton) findViewById(R.id.arrowpink01);
        ImageButton albumButton02 = (ImageButton) findViewById(R.id.arrowpink02);
        ImageButton albumButton03 = (ImageButton) findViewById(R.id.arrowpink03);
        ImageButton albumButton04 = (ImageButton) findViewById(R.id.arrowpink04);
        ImageButton albumButton05 = (ImageButton) findViewById(R.id.arrowpink05);
        ImageButton albumButton06 = (ImageButton) findViewById(R.id.arrowpink06);
        ImageView albuminformation = (ImageView) findViewById(R.id.albuminformation);

        playButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openMusicScreen = new Intent(MusicStructure.this, MusicScreen.class);
                startActivity(openMusicScreen);

            }
        });

        albumButton01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openMusicScreen = new Intent(MusicStructure.this, MusicScreen.class);
                startActivity(openMusicScreen);

            }
        });

        albumButton02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openMusicScreen = new Intent(MusicStructure.this, MusicScreen.class);
                startActivity(openMusicScreen);

            }
        });

        albumButton03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openMusicScreen = new Intent(MusicStructure.this, MusicScreen.class);
                startActivity(openMusicScreen);

            }
        });

        albumButton04.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openMusicScreen = new Intent(MusicStructure.this, MusicScreen.class);
                startActivity(openMusicScreen);

            }
        });

        albumButton05.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openMusicScreen = new Intent(MusicStructure.this, MusicScreen.class);
                startActivity(openMusicScreen);

            }
        });

        albumButton06.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openMusicScreen = new Intent(MusicStructure.this, MusicScreen.class);
                startActivity(openMusicScreen);

            }
        });

        albuminformation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent openMusicScreen = new Intent(MusicStructure.this, MusicScreen.class);
                startActivity((openMusicScreen));
            }
        });


    }
}
