package com.example.lindalabancz.jazzy;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;

public class MusicScreenSettings extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_screen_settings);

        ImageButton showedSettingsBack = (ImageButton) findViewById(R.id.settingssmall);

        showedSettingsBack.setOnClickListener(new View.OnClickListener(){
            @Override

            public void onClick (View view) {
                Intent showedSettingsBackIntent = new Intent (MusicScreenSettings.this, MusicScreen.class);
                startActivity(showedSettingsBackIntent);
            }
        });

    }
}
